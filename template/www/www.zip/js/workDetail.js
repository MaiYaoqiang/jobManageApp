var app = angular.module('manage', ['ionic']);
app.controller('parentCtrl', ['$scope',
  function ($scope) {



  }]);